import annyang;


annyang.setLanguage('ru');
var commands = {
'привет': function() {
    document.write('<h3>Приветствую, я голосовой ассистент!</h3>');
},
'пока': function() {
    document.write('<h3>Мы смогли, пока!</h3>');
}
};


console.log{
	привет
}